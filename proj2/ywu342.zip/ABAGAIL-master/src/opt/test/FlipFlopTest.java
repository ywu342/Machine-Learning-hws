package opt.test;

import java.io.IOException;
import java.util.Arrays;

import dist.DiscreteDependencyTree;
import dist.DiscreteUniformDistribution;
import dist.Distribution;

import opt.*;
import opt.example.*;
import opt.ga.CrossoverFunction;
import opt.ga.DiscreteChangeOneMutation;
import opt.ga.SingleCrossOver;
import opt.ga.GenericGeneticAlgorithmProblem;
import opt.ga.GeneticAlgorithmProblem;
import opt.ga.MutationFunction;
import opt.ga.StandardGeneticAlgorithm;
import opt.prob.GenericProbabilisticOptimizationProblem;
import opt.prob.MIMIC;
import opt.prob.ProbabilisticOptimizationProblem;
import shared.FixedIterationTrainer;
import shared.writer.CSVWriter;

import opt.DiscreteChangeOneNeighbor;
import opt.EvaluationFunction;
import opt.GenericHillClimbingProblem;
import opt.HillClimbingProblem;
import opt.NeighborFunction;
import opt.RandomizedHillClimbing;
import opt.SimulatedAnnealing;

/**
 * A test using the flip flop evaluation function
 * @author Andrew Guillory gtg008g@mail.gatech.edu
 * @version 1.0
 */
public class FlipFlopTest {
    /** The n value */
    private static final int N = 200;
    private static String OUTPUT_DIR = "outputs/";
    private int[] ranges = new int[N];
    private EvaluationFunction ef = new FlipFlopEvaluationFunction();
    private Distribution odd = new DiscreteUniformDistribution(ranges);
    private NeighborFunction nf = new DiscreteChangeOneNeighbor(ranges);
    private HillClimbingProblem hcp = new GenericHillClimbingProblem(ef, odd, nf);
    private int minIter = 50, maxIter = 10000, iterInterval = 200;

    public FlipFlopTest() {
        Arrays.fill(ranges, 2);
    }

    private void helper(String filename, int minIter, int maxIter, int iterInterval, OptimizationAlgorithm oa) throws IOException {
        String outputFile = OUTPUT_DIR+filename;
        CSVWriter writer = new CSVWriter(outputFile, new String[]{"Iterations", "Training Time", "Fitness"});
        writer.open();
        for (int i = minIter; i<=maxIter; i+=iterInterval) {
            double start = System.nanoTime(), trainingTime=0;
            FixedIterationTrainer fit = new FixedIterationTrainer(oa, i);
            fit.train();
            double end = System.nanoTime();
            double fitness = ef.value(oa.getOptimal());
            trainingTime = end-start;
            trainingTime /= Math.pow(10,9);
            String[] row = {i+"", trainingTime+"", fitness+""};
            writer.writeRow(Arrays.asList(row));
        }
        writer.close();
    }

    public void SATest() {
        try {
            helper("FF-SA.csv", minIter, maxIter, iterInterval, new SimulatedAnnealing(100, .95, hcp));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void GATest() {
        MutationFunction mf = new DiscreteChangeOneMutation(ranges);
        CrossoverFunction cf = new SingleCrossOver();
        GeneticAlgorithmProblem gap = new GenericGeneticAlgorithmProblem(ef, odd, mf, cf);
        try {
            helper("FF-GA.csv", minIter, maxIter, iterInterval, new StandardGeneticAlgorithm(200, 100, 20, gap));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void RHCTest() {
        try {
            helper("FF-RHC.csv", minIter, maxIter, iterInterval, new RandomizedHillClimbing(hcp));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void MIMICTest() {
        Distribution df = new DiscreteDependencyTree(.1, ranges);
        ProbabilisticOptimizationProblem pop = new GenericProbabilisticOptimizationProblem(ef, odd, df);
        try {
            helper("FF-MIMIC.csv", minIter, maxIter, iterInterval, new MIMIC(200, 5, pop));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        FlipFlopTest fft = new FlipFlopTest();
        fft.SATest();
        fft.RHCTest();
        fft.GATest();
        fft.MIMICTest();
/*
        RandomizedHillClimbing rhc = new RandomizedHillClimbing(hcp);
        FixedIterationTrainer fit = new FixedIterationTrainer(rhc, 200000);
        fit.train();
        System.out.println(ef.value(rhc.getOptimal()));
        
        SimulatedAnnealing sa = new SimulatedAnnealing(100, .95, hcp);
        fit = new FixedIterationTrainer(sa, 200000);
        fit.train();
        System.out.println(ef.value(sa.getOptimal()));
        
        StandardGeneticAlgorithm ga = new StandardGeneticAlgorithm(200, 100, 20, gap);
        fit = new FixedIterationTrainer(ga, 1000);
        fit.train();
        System.out.println(ef.value(ga.getOptimal()));
        
        MIMIC mimic = new MIMIC(200, 5, pop);
        fit = new FixedIterationTrainer(mimic, 1000);
        fit.train();
        System.out.println(ef.value(mimic.getOptimal()));
        */
    }
}
